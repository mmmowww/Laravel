﻿<?
$GEN_MYSQL = 'CREATE TABLE `Accaunt`.`Accaunt` ( `id` INT(255) NOT NULL AUTO_INCREMENT ,
                                              `Name` TEXT NOT NULL , `Email` TEXT NOT NULL ,
											  `Mobaile` INT NOT NULL , `Experience` DATE NOT NULL ,
											  `Skill` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;';
?>