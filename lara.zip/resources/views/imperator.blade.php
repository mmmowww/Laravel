﻿<html>
<!DOCTYPE>
<head>

</head>
<body>
<div class = "setings">
<p class = "client">CLient</p>
<p class = "W">Width</p>
<p class = "H">Height</p>
<p class = "using">USING</p>
<p class = "data">DATA</p>

</div>
<div class = "sate">
<div class = "menu">
<a href ="#">1</a>
<a href ="#">2</a>
<a href ="#">3</a>
<a href ="#">4</a>
</div>
<div class = "content">Content</div>
<div class = "foter">Footer</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="MayJS/MayJS_Client/js.js"></script>

</div>
</body>
</html>